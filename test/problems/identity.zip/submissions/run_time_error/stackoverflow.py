def f():
    f()


f()
